def disney_character(input_string):
    if "mickey" in input_string:
        output = True
    elif "donald" in input_string:
        output= True 
    elif "goofy" in input_string:
        output= True 
    elif "minnie" in input_string:
        output= True 
    elif "pluto" in input_string:
        output= True
    else:
        output= False
        
    return(output) 


def disney_character_output(input_string):
    if "mickey" in input_string:
        out_msg = "mickey is one of my favorite characters"
    elif "donald" in input_string:
        out_msg= "you know donald is always so angry"
    elif "minnie" in input_string:
        out_msg= "Minnie has always been super nice"
    elif "goofy" in input_string:
        out_msg= "Goofy has a son named max in college just like you"
    elif "pluto" in input_string:
        out_msg= "Pluto is the best of boys"
    return(out_msg)


def princess_check(input_string):
    if "cinderella" in input_string:
        output = True
    elif "snow white" in input_string:
        output= True 
    elif "ariel" in input_string:
        output= True 
    elif "jasmine" in input_string:
        output= True 
    elif "belle" in input_string:
        output= True
    elif "aurora" in input_string:
        output= True
    elif "elsa" in input_string:
        output= True
    else:
        output= False
        
    return(output) 


def princess_output(input_string):
    if "cinderella" in input_string:
        out_msg = "cinderella is so lucky to have her godmother"
    elif "snow white" in input_string:
        out_msg= "I wonder what would have happened if snow white would've just not taken food from a stranger"
    elif "ariel" in input_string:
        out_msg= "Sebastian has such good advice but flounder was really who saved ariel "
    elif "jasmine" in input_string:
        out_msg= "Jasmine really got to see the whole world on a flying carpet how lucky!!!!"
    elif "belle" in input_string:
        out_msg= "Belle not only helped save beast but also all of his servants too!!"
    return(out_msg)


def pixar_check(input_string):
    if "walle" in input_string:
        output = True
    elif "nemo" in input_string:
        output= True 
    elif "coco" in input_string:
        output= True 
    elif "cars" in input_string:
        output= True 
    elif "buzz lightyear" in input_string:
        output= True
    else:
        output= False
        
    return(output) 


def pixar_output(input_string):
    if "walle" in input_string:
        out_msg = "you know im really scared that we will end up like the world of walle"
    elif "nemo" in input_string:
        out_msg= "just keep swimming swimming swimming! WHERE IS NEMO"
    elif "coco" in input_string:
        out_msg= "miguel really chased his dream and and that led to finding out the truth and finding his grandpa "
    elif "cars" in input_string:
        out_msg= "lightning mcqueen is the fastest car there is!"
    elif "buzz lightyear" in input_string:
        out_msg= "To infinity and BEYOND!!!"
    return(out_msg)


def prepare_name(input_string):
    prep_name =  input_string + ": "
    return prep_name


def custom_print(string, how = "reverse", dur = 0, inline = True):
    if how == "reverse": 
        new_string = string
        while len(new_string) > 0:
            if inline == True: sys.stdout.write("\r")
            sys.stdout.write('{message: <{fill}}'.format(message=new_string, fill=str(len(string))))
            if inline == False: sys.stdout.write("\n")
            if inline == True: sys.stdout.flush()
            new_string = new_string[0:len(new_string) - 1]
            time.sleep(float(dur))     
    return new_string