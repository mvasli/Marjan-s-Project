# from my_modules.functions import *
# def test_function_name():
#     assert function_name(my_input) == #desiredvalue
    
from functions import *
def test_disney_character():
    assert disney_character("mickey") == True
    
from functions import *
def test_disney_character_output():
    assert disney_character_output('donald') == 'you know donald is always so angry'
    
from functions import *
def test_princess_check():
    assert princess_check('elsa') == True
    

from functions import *
def test_princess_output():
    assert princess_output('ariel') == 'Sebastian has such good advice but flounder was really who saved ariel '       

from functions import *
def test_pixar_check():
    assert pixar_check('nemo') == True
    
from functions import *
def test_pixar_output():
    assert pixar_output('buzz lightyear') == 'To infinity and BEYOND!!!'
    
    
from functions import *
def test_prepare_name():
    assert prepare_name('Marjan') == 'Marjan: '
    
    
  
        